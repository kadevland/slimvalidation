<?php

namespace App\RequestValidation;

namespace Slim\Http\Request;

use Respect\Validation\Validator as v

class ResquestContact extends RequestValidation{

	/**
     * List of constraints
     *
     * @var array
     */
    protected $rules = [	
			'tilte'=>V::alnum(),
			'email'=>V::email(),
			'message'=>V::alnum()->length(20,null)->setName('message'),
		];
    
    /**
     * List of customized messages
     *
     * @var array
     */
    protected $messages = [
	'alnum'                 => '{{name}}ne doit contenir que des caractères alphanumériques et des tirets.',
	'email'                 => "S'il vous plaît entré une adresse email correcte",
	'message'                 => "S'il vous plaît entré un message de 20 caratères minimum",

	];

    /**
     * List of returned errors in case of a failing assertion
     *
     * @var array
     */
    protected $errors = [];


}
