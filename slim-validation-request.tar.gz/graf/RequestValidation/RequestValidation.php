<?php

namespace App\RequestValidation;

namespace Slim\Http\Request;

use Respect\Validation\Validator as v

class RequestValidation{

	/**
     * List of constraints
     *
     * @var array
     */
    protected $rules = [];
    
    /**
     * List of customized messages
     *
     * @var array
     */
    protected $messages = [];

    /**
     * List of returned errors in case of a failing assertion
     *
     * @var array
     */
    protected $errors = [];

    public function valide(Request $request){

	
	foreach ($this->rules as $rule => $validator) {
        try {
            $validator->assert($request->getParam($rule));
        } catch (\Respect\Validation\Exceptions\NestedValidationExceptionInterface $ex) {
            $this->errors = $ex->findMessages($this->messages);
            return false;
        }

    }
	return true;

    }	
	    

    public function errors()
{
    return $this->errors;
}		





}
