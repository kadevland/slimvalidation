<?php


$settings = [
        'httpVersion' => '1.1',
        'responseChunkSize' =>4096,
        'outputBuffering' => 'append',
        'determineRouteBeforeAppMiddleware' => false,
        'displayErrorDetails'=> true,
        'addContentLengthHeader'=> false,
        'routerCacheFile' =>false,// realpath(__DIR__.'/../storage/cache/router/route.cache'),
        'storage'=>realpath(__DIR__.'/../storage'),
        'cache'=>realpath(__DIR__.'/../storage/cache'),
        'log'=>realpath(__DIR__.'/../storage/log'),
        'templates'=>[
                        'path'=>realpath(__DIR__.'/../templates'),
                        'cache'=>false,//realpath(__DIR__.'/../storage/cache/templates')
                    ],
        'assets'=>'assets',
        'js'=>'assets/js',
        'css'=>'assets/css',
        'database'=> require __DIR__.'/database.php',
];

return $settings;
